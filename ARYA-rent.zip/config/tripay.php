<?php

return [
    'TRIPAY_API_KEY' => env('TRIPAY_API_KEY'),
    'TRIPAY_PRIVATE_KEY' => env('TRIPAY_PRIVATE_KEY'),
    'MERCHANT_CODE' => env('MERCHANT_CODE'),

];