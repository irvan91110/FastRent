# Arya-rent

Tugas Besar Replika perangkat lunak
Kelompok 6

Anggota :\
ARYA BETA PUTRA PRATAMA (1301204354) - dokumentasi\
IRVAN ARDIANSYAH (1301204532) - database management/frontend/backend/deployment/server management/fullstack dah\
MUFIDAH ALFIAH (1301184180) - dokumentasi \
RAFIF BALTIRUS BUDIMAN(1301204443) - dokumentasi \
ROSYID AMRULLAH (1301204279) - UI/front end
